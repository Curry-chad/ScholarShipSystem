package com.scholarship.student.model;

public class Study {
private int sid; //רҵ���������к� ����
private String s_sCode;//רҵ����
private String s_name;//רҵ����
private String s_state;//רҵ״̬
public int getSid() {
	return sid;
}
public void setSid(int sid) {
	this.sid = sid;
}
public String getS_sCode() {
	return s_sCode;
}
public void setS_sCode(String code) {
	s_sCode = code;
}
public String getS_name() {
	return s_name;
}
public void setS_name(String s_name) {
	this.s_name = s_name;
}
public String getS_state() {
	return s_state;
}
public void setS_state(String s_state) {
	this.s_state = s_state;
}
}
