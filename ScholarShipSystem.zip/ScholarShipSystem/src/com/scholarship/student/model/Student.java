package com.scholarship.student.model;

/**
 * @author Administrator
 *
 */
public class Student {
	private int studentId;// ���кţ�����
	private String studentAccount;// �˺�
	private String studentPassword;// ����
	private String studentState;// ״̬
	private String studentRole;// ��ɫ
	private String studentName;// ����
	private String studentSex;// �Ա�
	private String studentBrithday;// ����
	private String studentNativePlace;// ���ᣬ���
	private String studentPolitical;// ������ò�����
	private String studentNation;// ���壬���
	private String studentIdCard;// ����֤
	private String studentClassName;// רҵ�༶���ƣ� ���
	private String studentTel;// �绰
	private String studentHomeAddress;// ��ͥ��ַ
	
	private String studentClassNumber; //רҵ����
	private String studentStatename;//״̬��

	public String getStudentStatename() {
		return studentStatename;
	}

	public void setStudentStatename(String studentStatename) {
		this.studentStatename = studentStatename;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentAccount() {
		return studentAccount;
	}

	public void setStudentAccount(String studentAccount) {
		this.studentAccount = studentAccount;
	}

	public String getStudentPassword() {
		return studentPassword;
	}

	public void setStudentPassword(String studentPassword) {
		this.studentPassword = studentPassword;
	}

	public String getStudentState() {
		return studentState;
	}

	public void setStudentState(String studentState) {
		this.studentState = studentState;
	}

	public String getStudentRole() {
		return studentRole;
	}

	public void setStudentRole(String studentRole) {
		this.studentRole = studentRole;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentSex() {
		return studentSex;
	}

	public void setStudentSex(String studentSex) {
		this.studentSex = studentSex;
	}

	public String getStudentBrithday() {
		return studentBrithday;
	}

	public void setStudentBrithday(String studentBrithday) {
		this.studentBrithday = studentBrithday;
	}

	public String getStudentNativePlace() {
		return studentNativePlace;
	}

	public void setStudentNativePlace(String studentNativePlace) {
		this.studentNativePlace = studentNativePlace;
	}

	public String getStudentPolitical() {
		return studentPolitical;
	}

	public void setStudentPolitical(String studentPolitical) {
		this.studentPolitical = studentPolitical;
	}

	public String getStudentNation() {
		return studentNation;
	}

	public void setStudentNation(String studentNation) {
		this.studentNation = studentNation;
	}

	public String getStudentIdCard() {
		return studentIdCard;
	}

	public void setStudentIdCard(String studentIdCard) {
		this.studentIdCard = studentIdCard;
	}

	public String getStudentClassName() {
		return studentClassName;
	}

	public void setStudentClassName(String studentClassName) {
		this.studentClassName = studentClassName;
	}

	public String getStudentTel() {
		return studentTel;
	}

	public void setStudentTel(String studentTel) {
		this.studentTel = studentTel;
	}

	public String getStudentHomeAddress() {
		return studentHomeAddress;
	}

	public void setStudentHomeAddress(String studentHomeAddress) {
		this.studentHomeAddress = studentHomeAddress;
	}

	public String getStudentClassNumber() {
		return studentClassNumber;
	}

	public void setStudentClassNumber(String studentClassNumber) {
		this.studentClassNumber = studentClassNumber;
	}
}
