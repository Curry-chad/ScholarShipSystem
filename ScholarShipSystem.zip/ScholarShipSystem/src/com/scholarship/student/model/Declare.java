package com.scholarship.student.model;

public class Declare {
	private int SID;
    private String Dec_title;//����������
    private String Dec_time;//������ʱ��
    private String Dec_info;//����������
    private String Dec_state;//������״̬
    
    private String Dec_statename;//������״̬��
    
	public int getSID() {
		return SID;
	}
	public void setSID(int sid) {
		SID = sid;
	}
	public String getDec_title() {
		return Dec_title;
	}
	public void setDec_title(String dec_title) {
		Dec_title = dec_title;
	}
	public String getDec_time() {
		return Dec_time;
	}
	public void setDec_time(String dec_time) {
		Dec_time = dec_time;
	}
	public String getDec_info() {
		return Dec_info;
	}
	public void setDec_info(String dec_info) {
		Dec_info = dec_info;
	}
	public String getDec_state() {
		return Dec_state;
	}
	public void setDec_state(String dec_state) {
		Dec_state = dec_state;
	}
	public String getDec_statename() {
		return Dec_statename;
	}
	public void setDec_statename(String dec_statename) {
		Dec_statename = dec_statename;
	}
}
