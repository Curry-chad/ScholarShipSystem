package com.scholarship.student.model;

public class StudyClass {
private int sid;//רҵ�༶�������к� ����
private String Stcode;//רҵ���� ���
private String StCcode;//רҵ�༶����
private String Stname;//רҵ�༶����
public int getSid() {
	return sid;
}
public void setSid(int sid) {
	this.sid = sid;
}
public String getStcode() {
	return Stcode;
}
public void setStcode(String stcode) {
	Stcode = stcode;
}
public String getStCcode() {
	return StCcode;
}
public void setStCcode(String stCcode) {
	StCcode = stCcode;
}
public String getStname() {
	return Stname;
}
public void setStname(String stname) {
	Stname = stname;
}
}
