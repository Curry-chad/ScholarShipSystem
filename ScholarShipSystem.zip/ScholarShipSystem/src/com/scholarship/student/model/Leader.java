package com.scholarship.student.model;

public class Leader {
      private int SID;
      private String Lea_account;//�쵼�ʺ�
      private String Lea_password;//�쵼����
      private String Lea_state;//�쵼״̬
      private String Lea_role;//�쵼��ɫ(ְλ)
      private String Lea_name;//�쵼����
	public int getSID() {
		return SID;
	}
	public void setSID(int sid) {
		SID = sid;
	}
	public String getLea_account() {
		return Lea_account;
	}
	public void setLea_account(String lea_account) {
		Lea_account = lea_account;
	}
	public String getLea_password() {
		return Lea_password;
	}
	public void setLea_password(String lea_password) {
		Lea_password = lea_password;
	}
	public String getLea_state() {
		return Lea_state;
	}
	public void setLea_state(String lea_state) {
		Lea_state = lea_state;
	}
	public String getLea_role() {
		return Lea_role;
	}
	public void setLea_role(String lea_role) {
		Lea_role = lea_role;
	}
	public String getLea_name() {
		return Lea_name;
	}
	public void setLea_name(String lea_name) {
		Lea_name = lea_name;
	}
      
      
}
