package com.scholarship.student.model;

public class StuClass {
     private String stcode; //רҵ���
     private String classname; //רҵ����
	public String getStcode() {
		return stcode;
	}
	public void setStcode(String stcode) {
		this.stcode = stcode;
	}
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}

}
