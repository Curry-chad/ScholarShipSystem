package com.scholarship.student.model;

public class Counsellor {
    private int SID;  //����Ա���
    private String Cou_account; //����Ա�ʺ�
    private String Cou_passwor; //����Ա����
    private String Cou_state; //�ʺ�״̬
    private String Cou_role;//��ɫ
    private String Cou_name;//����Ա����
    private String Cou_class; //רҵ
    
    private String Cou_statename; //�ʺ�״̬��
    private String Cou_classname; //רҵ����
    
 
	public String getCou_statename() {
		return Cou_statename;
	}
	public void setCou_statename(String cou_statename) {
		Cou_statename = cou_statename;
	}
	public String getCou_classname() {
		return Cou_classname;
	}
	public void setCou_classname(String cou_classname) {
		Cou_classname = cou_classname;
	}
	public int getSID() {
		return SID;
	}
	public void setSID(int sid) {
		SID = sid;
	}
	public String getCou_account() {
		return Cou_account;
	}
	public void setCou_account(String cou_account) {
		Cou_account = cou_account;
	}
	public String getCou_passwor() {
		return Cou_passwor;
	}
	public void setCou_passwor(String cou_passwor) {
		Cou_passwor = cou_passwor;
	}
	public String getCou_state() {
		return Cou_state;
	}
	public void setCou_state(String cou_state) {
		Cou_state = cou_state;
	}
	public String getCou_role() {
		return Cou_role;
	}
	public void setCou_role(String cou_role) {
		Cou_role = cou_role;
	}
	public String getCou_name() {
		return Cou_name;
	}
	public void setCou_name(String cou_name) {
		Cou_name = cou_name;
	}
	public String getCou_class() {
		return Cou_class;
	}
	public void setCou_class(String cou_class) {
		Cou_class = cou_class;
	}
	
	
}
