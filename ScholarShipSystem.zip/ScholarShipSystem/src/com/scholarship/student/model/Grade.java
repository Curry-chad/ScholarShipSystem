package com.scholarship.student.model;

public class Grade {
     private String stu_account; //ѧ���ʺ�
     private String stu_name; //ѧ������
     private String stuff; //ѧ�����ʷ�
     private String credit; //ѧ��ѧ��
     private String grade; //ѧ���ɼ��ܷ�
     private String grade_state; //ѧ���ɼ�״̬
     private String year; //ѧ��
	public String getStu_account() {
		return stu_account;
	}
	public void setStu_account(String stu_account) {
		this.stu_account = stu_account;
	}
	public String getStu_name() {
		return stu_name;
	}
	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}
	public String getStuff() {
		return stuff;
	}
	public void setStuff(String stuff) {
		this.stuff = stuff;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getGrade_state() {
		return grade_state;
	}
	public void setGrade_state(String grade_state) {
		this.grade_state = grade_state;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
}
     