package com.scholarship.student.dao;

import java.sql.*;

import com.scholarship.util.*;
import com.scholarship.common.exception.*;
import com.scholarship.student.model.*;


/**
 * @author Administrator
 *ѧ����DAO
 */
public class StudentDAO {
	public Student findStudentByNumber(String number) {
		String sql = "select * from t_studentinfo where Stu_account=?";
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		conn = DB.getConn();
		pstm = DB.prepareStatement(conn, sql);
		//Student student=new Student();����ֿ�ʱ���쳣
		Student student = null;
		try {
			pstm.setString(1, number);
			rs = pstm.executeQuery();
			if (rs.next()) {
				student = new Student();
				student.setStudentId(rs.getInt("SID"));
				student.setStudentAccount(rs.getString("Stu_account"));
				student.setStudentPassword(rs.getString("Stu_password").trim());
				student.setStudentState(rs.getString("Stu_state"));
				student.setStudentRole(rs.getString("Stu_role"));
				student.setStudentName(rs.getString("Stu_name"));
				student.setStudentSex(rs.getString("Stu_sex"));
				student.setStudentBrithday(rs.getString("Stu_birthday"));
				student.setStudentNativePlace("nativePlace");
				student.setStudentPolitical(rs.getString("political"));
				student.setStudentNation(rs.getString("nation"));
				student.setStudentIdCard(rs.getString("IdCard"));
				student.setStudentClassName(rs.getString("S_StClassName"));
				student.setStudentTel(rs.getString("Stu_tel"));
				student.setStudentHomeAddress(rs.getString("homeAddress"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("����ѧ�����˺Ų�ѯʧ�ܣ�");
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(pstm);
			DB.close(conn);
		}

		return student;
	}

	/**
	 * @param number
	 * @param password
	 * @return
	 * @throws UserNotFoundException 
	 */
	public Student StudentLogin(String number, String password) throws PasswordErrorException, UserNotFoundException {
		Student student = this.findStudentByNumber(number);
		if (student != null) {
			String pwd = student.getStudentPassword();
			String state = student.getStudentState();
			if ((pwd!=null&& (!pwd.equals(password)))||(!state.equals("0501"))) {
				throw new PasswordErrorException("password error!");
			}
		} else {
			throw new UserNotFoundException("user unfound!");
		}
		return student;
	}
	
	//��������Ա��Ϣ
		public Counsellor findCounsellorByNumber(String number) {
			String sql = "select * from t_CounsellorInfo where Cou_account=?";
			Connection conn = null;
			PreparedStatement pstm = null;
			ResultSet rs = null;
			conn = DB.getConn();
			pstm = DB.prepareStatement(conn, sql);
			Counsellor counsellor = null;
			try {
				pstm.setString(1, number);
				rs = pstm.executeQuery();
				if (rs.next()) {
					counsellor = new Counsellor();
					counsellor.setSID(rs.getInt("SID"));
					counsellor.setCou_account(rs.getString("Cou_account"));
					counsellor.setCou_passwor(rs.getString("Cou_password").trim());
					counsellor.setCou_state(rs.getString("Cou_state"));
					counsellor.setCou_role(rs.getString("Cou_role"));					
					counsellor.setCou_name(rs.getString("Cou_name"));
					counsellor.setCou_class(rs.getString("Cou_class"));
	
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("���ݸ���Ա���˺Ų�ѯʧ�ܣ�");
				e.printStackTrace();
			} finally {
				DB.close(rs);
				DB.close(pstm);
				DB.close(conn);
			}

			return counsellor;
		}
	
		//�жϸ���Ա��¼
		public Counsellor CounsellorLogin(String number, String password) throws PasswordErrorException, UserNotFoundException {
			Counsellor counsellor = this.findCounsellorByNumber(number);
			if (counsellor != null) {
				String pwd = counsellor.getCou_passwor();
				String state = counsellor.getCou_state();
				if ((pwd!=null&& (!pwd.equals(password)))||(!state.equals("0401"))) {
					throw new PasswordErrorException("password error!");
				}
			} else {
				throw new UserNotFoundException("user unfound!");
			}
			return counsellor;
		}
	
	       //�����쵼��Ϣ
		private Leader findLeaderByNumber(String number) {
			String sql = "select SID,Lea_account,Lea_password,Lea_state ,Lea_role,Lea_name from t_LeaderInfo where Lea_account=?";
			Connection conn = null;
			PreparedStatement pstm = null;
			ResultSet rs = null;
			conn = DB.getConn();
			pstm = DB.prepareStatement(conn, sql);
			Leader leader = null;
			try {
				pstm.setString(1,number);
				rs = pstm.executeQuery();
				if (rs.next()) {
					leader = new Leader();
					leader.setSID(rs.getInt("SID"));
					leader.setLea_account(rs.getString("Lea_account"));
					leader.setLea_password(rs.getString("Lea_password").trim());
					leader.setLea_state(rs.getString("Lea_state"));
					leader.setLea_role(rs.getString("Lea_role"));
					leader.setLea_name(rs.getString("Lea_name"));
					
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("�����쵼���˺Ų�ѯʧ�ܣ�");
				e.printStackTrace();
			} finally {
				DB.close(rs);
				DB.close(pstm);
				DB.close(conn);
			}

			return leader;
		}
	    //�쵼��¼
		public Leader LeaderLogin(String number, String password) throws PasswordErrorException, UserNotFoundException {
			Leader leader = this.findLeaderByNumber(number);
			if (leader != null) {
				String pwd = leader.getLea_password();
				if (pwd!=null&& (!pwd.equals(password))) {
					throw new PasswordErrorException("password error!");
				}
			} else {
				throw new UserNotFoundException("user unfound!");
			}
			return leader;
		}
	
}
