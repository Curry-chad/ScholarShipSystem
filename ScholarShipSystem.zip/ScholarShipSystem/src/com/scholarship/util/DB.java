package com.scholarship.util;

import java.sql.*;

public class DB {
	private static Connection conn;
	private static PreparedStatement pstm;
	private static Statement stmt;
	private static ResultSet rs;
	//private static String driver = "org.gjt.mm.mysql.Driver";
	//private static String url = "jdbc:mysql://127.0.0.1/scholarship";
//     private static String user = "";
//	private static String pw = "";
	
	private static String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
	private static String url = "jdbc:odbc:school";
	static{
    	try{
    		Class.forName(driver);
    	}
    	catch(ClassNotFoundException ex){
    	System.out.println("����������ʧ��");	
    	ex.printStackTrace();
    	}
    }
    public static Connection getConn(){
    	Connection conn = null;
    	try{
    		conn=DriverManager.getConnection(url);
    	}
    	catch(SQLException ex){
    	System.out.println("���ݿ�����ʧ��");
    	ex.printStackTrace();
    	}
    	return conn;
    }
    //����Statement
    //��һ�����ж���һ������Ϊstatic���Ǿ���˵�����豾��Ķ��󼴿ɵ��ô˷���
    public static Statement createStatement(Connection conn){
    	try{
    		stmt=conn.createStatement();
    	}
    	catch(SQLException ex){
    		System.out.println("���ݿⴴ��ʧ��");
    		ex.printStackTrace();
    	}
    	return stmt;
    }
    //   //��һ�����ж���һ������Ϊstatic���Ǿ���˵�����豾��Ķ��󼴿ɵ��ô˷���
    public static ResultSet executeQuery(Statement stmt,String sql){
    	try{
    		rs=stmt.executeQuery(sql);
    	}
    	catch(SQLException ex){
    		System.out.println("���ݿ��ѯʧ��");
    		ex.printStackTrace();
    	}
    	return rs;
    }
    public static PreparedStatement prepareStatement(Connection conn,String sql){
    	PreparedStatement pstm=null;
    	try{
    		pstm=conn.prepareStatement(sql);
    	}
    	catch(SQLException ex){
    		System.out.println("���ݿⴴ��PreparedStatementʧ��");
    		ex.printStackTrace();
    	}
    	return pstm;
    }
    public int executeUpdate(String sql){
    	int result=0;
    	try{
    		result=stmt.executeUpdate(sql);
    	}
    	catch(SQLException ex){
    		System.out.println("���ݿ����ʧ��");
    		ex.printStackTrace();
    		result=0;
    	}
    	return result;
    }
    public static void close(Connection conn){
    	if(conn !=null){
    		try{
    			conn.close();
    		}
    		catch(SQLException ex){
    			System.out.println("���ݿ����ӹر�ʧ��");
    			ex.printStackTrace();
    		}
    	}
    }
    public static void close(Statement stmt){
    	if(stmt !=null){
    		try{
    			stmt.close();
    		}
    		catch(SQLException ex){
    			System.out.println("�ر�Statementʧ��");
    			ex.printStackTrace();
    		}
    	}
    }
    public static void close(PreparedStatement pstm){
    	if(pstm !=null){
    		try{
    			pstm.close();
    		}
    		catch(SQLException ex){
    			System.out.println("�ر�PreparedStatementʧ��");
    			ex.printStackTrace();
    		}
    	}
    }
    public static void close(ResultSet rs){
    	if(rs !=null){
    		try{
    			rs.close();
    		}
    		catch(SQLException ex){
    			System.out.println("���ݿ������رճ���");
    			ex.printStackTrace();
    		}
    	}
    }
}

