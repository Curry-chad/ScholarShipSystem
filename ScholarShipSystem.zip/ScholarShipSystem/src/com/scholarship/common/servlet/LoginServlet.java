package com.scholarship.common.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.scholarship.common.exception.PasswordErrorException;
import com.scholarship.common.exception.UserNotFoundException;
import com.scholarship.student.model.Counsellor;
import com.scholarship.student.model.Leader;
import com.scholarship.student.model.Student;
import com.scholarship.student.dao.*;

public class LoginServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public LoginServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}
	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
      String number=request.getParameter("username");
      String password=request.getParameter("password");
      String loginType=request.getParameter("loginType");
      try{
      if("1".equals(loginType)){
    	   
    	  StudentDAO dao=new StudentDAO();
    	  Student student= dao.StudentLogin(number, password); 
 		  if(student.getStudentAccount().equals(number)&&student.getStudentPassword().equals(password)&&student.getStudentState().equals("0501")){
    	  {
    		      HttpSession session=request.getSession(false);
    			  session=request.getSession(true);
    			  session.setAttribute("userID",number);  	
    			  
    		  request.getRequestDispatcher("student/student_index.jsp").forward(request, response);
    	      }
 		     }		    
      }
      
      if("2".equals(loginType)){
   	   
    	  StudentDAO dao=new StudentDAO();
    	  Counsellor counsellor= dao.CounsellorLogin(number, password); 
 		  if(counsellor.getCou_account().equals(number)&&counsellor.getCou_passwor().equals(password)&&counsellor.getCou_state().equals("0401")){
    	  {
    		      HttpSession session=request.getSession(false);
    			  session=request.getSession(true);
    			  session.setAttribute("userID",number);  	
    		  request.getRequestDispatcher("counsellor/counsellor_index.jsp").forward(request, response);
    	      }
 		     }		    
      }
      if("3".equals(loginType)){
    	  StudentDAO dao=new StudentDAO();
          Leader leader =dao.LeaderLogin(number,password);
 		  if(leader.getLea_account().equals(number)&&leader.getLea_password().equals(password)){
 			  {
 				    HttpSession session=request.getSession(false);
 				    session=request.getSession(true);
 	    			session.setAttribute("userID",number);  
 		     request.getRequestDispatcher("leader/leader_index.jsp").forward(request, response);

 			  }
            }   
      } 
      }catch(PasswordErrorException e){
    	  //System.out.print("dfdsfdsafds");
    	  String msg=e.getMessage();
    	  request.setAttribute("error",msg);
    	  request.getRequestDispatcher("loginFailed.jsp").forward(request, response);
      }catch(UserNotFoundException e){
    	  //System.out.print("dfdsfdsafds");
    	  String msg=e.getMessage();
    	  request.setAttribute("error",msg);
    	  request.getRequestDispatcher("loginFailed.jsp").forward(request, response);
      }
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
