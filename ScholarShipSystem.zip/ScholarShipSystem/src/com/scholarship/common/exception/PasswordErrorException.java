package com.scholarship.common.exception;

/**
 * @author Administrator
 *
 */
public class PasswordErrorException extends Exception {
   public PasswordErrorException(String msg){
	   super(msg);
   }
}

