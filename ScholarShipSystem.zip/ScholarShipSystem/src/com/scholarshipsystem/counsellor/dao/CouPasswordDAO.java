package com.scholarshipsystem.counsellor.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.scholarship.student.model.Counsellor;
import com.scholarship.util.DB;

public class CouPasswordDAO {
	//�޸ĸ���Ա����
	public void updateCouPassword(String user_ID,String password) {
		String sql = "update t_CounsellorInfo set Cou_password=? where Cou_account=?";
		Connection conn = null;
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;
	  try {
		  conn = DB.getConn();
		   pstmt = DB.prepareStatement(conn, sql);
		   pstmt.setString(1,password);
		   pstmt.setString(2,user_ID);
		   
		   pstmt.executeUpdate();
	         } catch (SQLException e) {
			e.printStackTrace();
	         } finally {
	    	       DB.close(rs);
		           DB.close(pstmt);
		           DB.close(conn);
                      }
	}
}
