package com.scholarshipsystem.counsellor.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.scholarship.util.DB;
import com.scholarshipsystem.student.model.ApManage;
import com.scholarshipsystem.student.model.HomeSituation;

public class CouApManageDAO {
	 //����ѧ�Ų�����ص�����������
    public List<ApManage> findAllConApManagebyClass(String classnumber)
    {
  	  List<ApManage> list=null;
  	  String sql="select a.SID,a.S_StClassName,a.years,b.name,a.ApTitle,a.Stu_account,c.names,a.ApContent,a.Cou_name,a.Lea_name,a.typeName,d.yearname,e.S_ClassName from t_ApManage a,t_business b,(select name as names,numbers from t_business ) c,t_Year d,t_StudyClass e where a.typeName=b.numbers and a.stateName=c.numbers and d.yearCode=a.years and a.S_StClassName=e.S_Stcode and a.S_StClassName=? and stateName=0102";

  	      Connection conn = null;
		  PreparedStatement pstmt = null;
		  ResultSet rs = null;
		  ApManage apManage = null;

		try {
			list = new ArrayList<ApManage>();
			
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
		    pstmt.setString(1,classnumber);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				apManage = new ApManage();
				apManage.setApM_id(rs.getInt("SID"));
 				apManage.setS_StClassName(rs.getString("S_StClassName"));
 				apManage.setYears(rs.getString("years"));
 				apManage.setTypeName(rs.getString("name"));
 				apManage.setApTitle(rs.getString("ApTitle"));
 				apManage.setStu_account(rs.getString("Stu_account"));
 				apManage.setStateName(rs.getString("names"));
 				apManage.setApContent(rs.getString("ApContent"));
 				apManage.setCou_name(rs.getString("Cou_name"));
 				apManage.setLea_name(rs.getString("Lea_name"));		
 				apManage.setTypenumber(rs.getString("typeName"));
 				apManage.setYearsname(rs.getString("yearname"));
 				apManage.setS_StClassNamenumber(rs.getString("S_ClassName"));
				
				list.add(apManage);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(pstmt);
			DB.close(conn);
		}

		return list;
  	     }
    
    //����SID������Ӧ��������
    public ApManage findConApManagebySID(String SID)
    {
  	  String sql="select a.SID,a.S_StClassName,a.years,b.name,a.ApTitle,a.Stu_account,c.names,a.ApContent,a.Cou_name,a.Lea_name,a.typeName,d.yearname,e.S_ClassName from t_ApManage a,t_business b,(select name as names,numbers from t_business ) c,t_Year d,t_StudyClass e where a.typeName=b.numbers and a.stateName=c.numbers and d.yearCode=a.years and a.S_StClassName=e.S_Stcode and a.SID=?";


  	      Connection conn = null;
		  PreparedStatement pstmt = null;
		  ResultSet rs = null;
		  ApManage apManage = null;

		try {		
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
		    pstmt.setString(1,SID);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				apManage = new ApManage();
				apManage.setApM_id(rs.getInt("SID"));
				apManage.setS_StClassName(rs.getString("S_StClassName"));
				apManage.setYears(rs.getString("years"));
				apManage.setTypeName(rs.getString("name"));
				apManage.setApTitle(rs.getString("ApTitle"));
				apManage.setStu_account(rs.getString("Stu_account"));
				apManage.setStateName(rs.getString("names"));
				apManage.setApContent(rs.getString("ApContent"));
				apManage.setCou_name(rs.getString("Cou_name"));
				apManage.setLea_name(rs.getString("Lea_name"));		
				apManage.setTypenumber(rs.getString("typeName"));
				apManage.setYearsname(rs.getString("yearname"));
				apManage.setS_StClassNamenumber(rs.getString("S_ClassName"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(pstmt);
			DB.close(conn);
		}

		   return apManage;
  	     }
    //ͨ���˺Ų�ѯ����Ա����רҵ
    public String findConClassByNumber(String number){
              String sql="select Cou_class from t_CounsellorInfo where Cou_account=?";

      	      Connection conn = null;
    		  PreparedStatement pstmt = null;
    		  ResultSet rs = null;
    		  ApManage apManage = null;
    		  String classnumber=null;

    		try {		
    			conn = DB.getConn();
    			pstmt = DB.prepareStatement(conn, sql);
    		    pstmt.setString(1,number);
    			rs = pstmt.executeQuery();
    			while (rs.next()) {
    			classnumber=rs.getString("Cou_class");				
    			}
    		} catch (SQLException e) {
    			e.printStackTrace();
    		} finally {
    			DB.close(rs);
    			DB.close(pstmt);
    			DB.close(conn);
    		}

    		   return classnumber;
      	     }
    
    //�޸���������Ӧ��״̬
    public void updAplicationstateBySID(String state,String SID){
    String sql = "update t_ApManage set stateName=? where SID=?";
      Connection conn = null;
	   PreparedStatement pstmt = null;
	   ResultSet rs = null;
	  try {
		conn = DB.getConn();
		pstmt = DB.prepareStatement(conn, sql);
		pstmt.setString(1,state);
		pstmt.setString(2,SID);      
		pstmt.executeUpdate();
	         } catch (SQLException e) {
			e.printStackTrace();
	         } finally {
	    	           DB.close(rs);
		           DB.close(pstmt);
		           DB.close(conn);
                    }
     }
    
  //������ͥ���� 
    public List<HomeSituation> findCouHomeSituationbyID(String account)
    {
  	  List<HomeSituation> list=null;
  	  String sql="select SID,Stu_account,merberName,homeMerL,work,workPlace,yearEarning from t_HomeSituation where Stu_account=?";
		      
	      Connection conn = null;
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;
	      HomeSituation homeSituation = null;
	      try {
	  			list = new ArrayList<HomeSituation>();
	  			
	  			conn = DB.getConn();
	  			pstmt = DB.prepareStatement(conn, sql);
	  			pstmt.setString(1,account);
	  			rs = pstmt.executeQuery();

	  			while (rs.next()) {
	  				homeSituation = new HomeSituation();  				
	  				homeSituation.setSID(rs.getInt("SID"));				
	  				homeSituation.setStu_account(rs.getString("Stu_account"));
	  				homeSituation.setMerberName(rs.getString("merberName"));
	  				homeSituation.setHomeMerL(rs.getString("homeMerL"));
	  				homeSituation.setWork(rs.getString("work"));
	  				homeSituation.setWorkPlace(rs.getString("workPlace"));
	  				homeSituation.setYearEarning(rs.getString("yearEarning"));
	  				
	  				list.add(homeSituation);
	  			}
	  		} catch (SQLException e) {
	  			e.printStackTrace();
	  		} finally {
	  			DB.close(rs);
	  			DB.close(pstmt);
	  			DB.close(conn);
	  		}

	  		return list;  
      }
}
