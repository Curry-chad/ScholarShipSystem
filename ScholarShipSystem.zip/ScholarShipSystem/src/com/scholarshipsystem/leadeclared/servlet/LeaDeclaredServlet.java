package com.scholarshipsystem.leadeclared.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.scholarship.student.model.Declare;
import com.scholarshipsystem.couapmanage.servlet.CouApmanageShowServlet;
import com.scholarshipsystem.leader.dao.LeaDeclaredDAO;

public class LeaDeclaredServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public LeaDeclaredServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		request.setCharacterEncoding("GB2312");
		this.doGet(request, response);
      }

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("GB2312");
		LeaDeclaredDAO leaDeclaredDAO=new LeaDeclaredDAO();
		String action=request.getParameter("action");
		String SID=request.getParameter("SID");
		if(action.equals("FB")){
			    request.setAttribute("action",action+"1");
				request.setAttribute("LDelist",leaDeclaredDAO.findByID(SID));
				request.getRequestDispatcher("../leader/LeaDeclared_FB.jsp").forward(request, response);			
		}
		if(action.equals("FB1")){
			String state=request.getParameter("state");
			leaDeclaredDAO.updDeclareBystate(SID, state);
			(new LeaDeclaredShowServlet()).service(request, response);
	
		}
		if(action.equals("GX")){
			String state=request.getParameter("state");
			if(state.equals("0302")){
				request.setAttribute("Info",new String("�˹����ѷ��������Ƚ��ù���ȡ������!"));
				request.getRequestDispatcher("../leader/leawarning.jsp").forward(request, response);
			   }
			else{
				request.setAttribute("action",action+"1");
				request.setAttribute("LDelist",leaDeclaredDAO.findByID(SID));
				request.getRequestDispatcher("../leader/LeaDeclared_ADD.jsp").forward(request, response);
			}			
		}
		if(action.equals("GX1")){
			Declare declare=new Declare();
			String title=request.getParameter("Title");
			String apContent=request.getParameter("ApContent");
			declare.setDec_title(title);
			declare.setDec_info(apContent);
			leaDeclaredDAO.updDeclare(SID, declare);
			
			(new LeaDeclaredShowServlet()).service(request, response);		
		}
		if(action.equals("SC")){
			   String state=request.getParameter("state");
		       if(state.equals("0302")){
			      request.setAttribute("Info",new String("�˹����ѷ��������Ƚ��ù���ȡ������!"));
			      request.getRequestDispatcher("../leader/leawarning.jsp").forward(request, response);
		            }
		        else{
		             request.setAttribute("action",action+"1");
			         request.setAttribute("LDelist",leaDeclaredDAO.findByID(SID));
			         request.getRequestDispatcher("../leader/LeaDeclared_FB.jsp").forward(request, response);			
	  		        }	
		   }
		
		if(action.equals("SC1")){
			leaDeclaredDAO.delDeclare(SID);
			
			(new LeaDeclaredShowServlet()).service(request, response);		
		}
				
		if(action.equals("ADD")){
			request.setAttribute("action",action+"1");
			request.setAttribute("LDelist",leaDeclaredDAO.setDeclarenull(new Declare()));		
			request.getRequestDispatcher("../leader/LeaDeclared_ADD.jsp").forward(request, response);		
		   }
		if(action.equals("ADD1")){
			Declare declare=new Declare();
			String title=request.getParameter("Title");
			String apContent=request.getParameter("ApContent");
			declare.setDec_title(title);
			declare.setDec_info(apContent);
			leaDeclaredDAO.addDeclare(declare);		
			(new LeaDeclaredShowServlet()).service(request, response);
			}
		
		
		
			
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
