package com.scholarshipsystem.leaaccounts.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.scholarshipsystem.leadeclared.servlet.LeaDeclaredShowServlet;
import com.scholarshipsystem.leader.dao.LeaAccountsDAO;
import com.scholarshipsystem.leader.dao.LeaDeclaredDAO;

public class LeaaccountsServlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public LeaaccountsServlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("GB2312");
		LeaAccountsDAO leaAccountsDAO=new LeaAccountsDAO();
		String action=request.getParameter("action");
		String account=request.getParameter("account");
		if(action.equals("Cupdate")){
			    request.setAttribute("Coustate",leaAccountsDAO.findAllstate("04"));
			    request.setAttribute("StuClass",leaAccountsDAO.findAllclass());
				request.setAttribute("CAlist",leaAccountsDAO.findCounsellorByaccount(account));		
				request.getRequestDispatcher("../leader/Couaccounts_Show_go.jsp").forward(request, response);			
		}
		if(action.equals("Cupdate1")){
			String state=request.getParameter("state"); 
			String courseCode=request.getParameter("courseCode"); 
			leaAccountsDAO.updCouAccountstateByaccount(state, courseCode, account);
			(new LeaaccountsShowServlet()).service(request, response);
		}
		if(action.equals("Cdelete")){
		     request.setAttribute("CAlist",leaAccountsDAO.findCounsellorByaccount(account));		
		     request.getRequestDispatcher("../leader/Couaccounts_Del.jsp").forward(request, response);
		}
		
		if(action.equals("Cdelete1")){
			leaAccountsDAO.delCouaccount(account);		
			(new LeaaccountsShowServlet()).service(request, response);
		}
		if(action.equals("Supdate")){
			request.setAttribute("Stustate",leaAccountsDAO.findAllstate("05"));
			request.setAttribute("SAlist",leaAccountsDAO.findStudentByaccount(account));
			request.getRequestDispatcher("../leader/Stuaccounts_Show_go.jsp").forward(request, response);
		}
		if(action.equals("Supdate1")){
			String state=request.getParameter("state");
			leaAccountsDAO.updStuAccountstateByaccount(state, account);
			request.setAttribute("SAlist",leaAccountsDAO.findAllStudent());
			request.getRequestDispatcher("../leader/Stuaccounts_Show.jsp").forward(request, response);
		}
		if(action.equals("Sdelete")){		
			
			request.setAttribute("SAlist",leaAccountsDAO.findStudentByaccount(account));		
		    request.getRequestDispatcher("../leader/Stuaccounts_Del.jsp").forward(request, response);			
		}
		if(action.equals("Sdelete1")){
			leaAccountsDAO.delStuaccount(account);
			(new LeaaccountsShowServlet()).service(request, response);
		}
		if(action.equals("Cadd")){
			 request.setAttribute("Coustate",leaAccountsDAO.findAllstate("04"));
			 request.setAttribute("StuClass",leaAccountsDAO.findAllclass());
			 request.getRequestDispatcher("../leader/Couaccounts_Add.jsp").forward(request, response);
		}
		if(action.equals("Cadd1")){
			String state=request.getParameter("state"); 
			String courseCode=request.getParameter("courseCode"); 
			leaAccountsDAO.addCouaccount(state, courseCode, account);
			(new LeaaccountsShowServlet()).service(request, response);
		}
		if(action.equals("Sadd")){
			request.setAttribute("Stustate",leaAccountsDAO.findAllstate("05"));
			request.getRequestDispatcher("../leader/Stuaccounts_Add.jsp").forward(request, response);
			
		}
		if(action.equals("Sadd1")){
			String state=request.getParameter("state"); 
			leaAccountsDAO.addStudent(state, account);
			(new LeaaccountsShowServlet()).service(request, response);
			
		}
		
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out
				.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the POST method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
