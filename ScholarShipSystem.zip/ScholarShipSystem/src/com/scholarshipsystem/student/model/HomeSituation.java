package com.scholarshipsystem.student.model;

public class HomeSituation {
	  private int SID; //��ͥ�������
      private String Stu_account; //ѧ���ʺ�
      private String merberName; //��Ա����
      private String homeMerL;   //��ͥ��Ա��ϵ
      private String work; //ְҵ
      private String workPlace;  //������λ
      private String yearEarning; //������    
      
      
	public int getSID() {
		return SID;
	}
	public void setSID(int sid) {
		SID = sid;
	}
	public String getStu_account() {
		return Stu_account;
	}
	public void setStu_account(String stu_account) {
		Stu_account = stu_account;
	}
	public String getMerberName() {
		return merberName;
	}
	public void setMerberName(String merberName) {
		this.merberName = merberName;
	}
	public String getHomeMerL() {
		return homeMerL;
	}
	public void setHomeMerL(String homeMerL) {
		this.homeMerL = homeMerL;
	}
	public String getWork() {
		return work;
	}
	public void setWork(String work) {
		this.work = work;
	}
	public String getWorkPlace() {
		return workPlace;
	}
	public void setWorkPlace(String workPlace) {
		this.workPlace = workPlace;
	}
	public String getYearEarning() {
		return yearEarning;
	}
	public void setYearEarning(String yearEarning) {
		this.yearEarning = yearEarning;
	}
}  
