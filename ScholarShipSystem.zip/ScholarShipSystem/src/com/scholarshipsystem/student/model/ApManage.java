package com.scholarshipsystem.student.model;

/**
 * @author Administrator
 * 
 */
public class ApManage {
	private int ApM_id; // ���������к�
	private String S_StClassName; // רҵ�༶����
	private String years; // �꼶����
	private String typeName; // ��ѧ�����
	private String ApTitle; // ���������
	private String Stu_account; // ѧ���ʺ�
	private String stateName; // ������״̬
	private String ApContent; // ����������
	private String Cou_name; // ����Ա����
	private String ApReCode1; // ����Ա������
	private String Lea_name; // ������Ա����
	private String ApReCode2; // ������Ա������
	
	private String typenumber;// ��ѧ��������
	private String yearsname;   //�꼶����
	private String S_StClassNamenumber; // רҵ�༶����
	

	public int getApM_id() {
		return ApM_id;
	}

	public void setApM_id(int apM_id) {
		ApM_id = apM_id;
	}

	public String getS_StClassName() {
		return S_StClassName;
	}

	public void setS_StClassName(String stClassName) {
		S_StClassName = stClassName;
	}

	public String getYears() {
		return years;
	}

	public void setYears(String years) {
		this.years = years;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public String getApTitle() {
		return ApTitle;
	}

	public void setApTitle(String apTitle) {
		ApTitle = apTitle;
	}

	public String getStu_account() {
		return Stu_account;
	}

	public void setStu_account(String stu_account) {
		Stu_account = stu_account;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getApContent() {
		return ApContent;
	}

	public void setApContent(String apContent) {
		ApContent = apContent;
	}

	public String getCou_name() {
		return Cou_name;
	}

	public void setCou_name(String cou_name) {
		Cou_name = cou_name;
	}

	public String getApReCode1() {
		return ApReCode1;
	}

	public void setApReCode1(String apReCode1) {
		ApReCode1 = apReCode1;
	}

	public String getLea_name() {
		return Lea_name;
	}

	public void setLea_name(String lea_name) {
		Lea_name = lea_name;
	}

	public String getApReCode2() {
		return ApReCode2;
	}

	public void setApReCode2(String apReCode2) {
		ApReCode2 = apReCode2;
	}

	public String getTypenumber() {
		return typenumber;
	}

	public void setTypenumber(String typenumber) {
		this.typenumber = typenumber;
	}

	public String getYearsname() {
		return yearsname;
	}

	public void setYearsname(String yearsname) {
		this.yearsname = yearsname;
	}

	public String getS_StClassNamenumber() {
		return S_StClassNamenumber;
	}

	public void setS_StClassNamenumber(String stClassNamenumber) {
		S_StClassNamenumber = stClassNamenumber;
	}
   
	
}
