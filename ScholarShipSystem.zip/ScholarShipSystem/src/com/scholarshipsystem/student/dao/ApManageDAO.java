package com.scholarshipsystem.student.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.scholarship.student.model.ScholarShipType;
import com.scholarship.student.model.StuClass;
import com.scholarship.student.model.Year;
import com.scholarship.util.*;
import com.scholarshipsystem.student.model.*;

/**
 * @author Administrator
 * 
 */

public class ApManageDAO {

	/**
	 * @param ap
	 */
	
	 public void addAplication(ApManage AP){
	       String sql = "insert into t_ApManage (S_StClassName,years,typeName,ApTitle,Stu_account,stateName,ApContent,Cou_name,ApReCode1,Lea_name,ApReCode2) values (?,?,?,?,?,?,?,?,?,?,?)";
	       Connection conn = null;
		   PreparedStatement pstmt = null;
		   ResultSet rs = null;
		   
		  try {
		    conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			pstmt.setString(1,AP.getS_StClassName());
	        pstmt.setString(2,AP.getYears()); 
	        pstmt.setString(3,AP.getTypeName());
	        pstmt.setString(4,AP.getApTitle());
	        pstmt.setString(5,AP.getStu_account());
	        pstmt.setString(6,AP.getStateName());
	        pstmt.setString(7,AP.getApContent());
	        pstmt.setString(8,AP.getCou_name());
	        pstmt.setString(9,AP.getApReCode1());
	        pstmt.setString(10,AP.getLea_name());
	        pstmt.setString(11,AP.getApReCode2());
			pstmt.executeUpdate();
		         } catch (SQLException e) {
				e.printStackTrace();
		         } finally {
		    	       DB.close(rs);
			           DB.close(pstmt);
			           DB.close(conn);
	                       }

	        }
	 //����ѧ�Ų�����ص�����������
     public List<ApManage> findAllApManagebyID(String ID)
     {
   	  List<ApManage> list=null;
   	  String sql="select a.SID,a.S_StClassName,a.years,b.name,a.ApTitle,a.Stu_account,c.names,a.ApContent,a.Cou_name,a.ApReCode1,a.Lea_name,a.ApReCode2 from t_ApManage a,t_business b,(select name as names,numbers from t_business ) c where a.typeName=b.numbers and a.stateName=c.numbers and Stu_account=?";


   	      Connection conn = null;
 		  PreparedStatement pstmt = null;
 		  ResultSet rs = null;
 		  ApManage apManage = null;

 		try {
 			list = new ArrayList<ApManage>();
 			
 			conn = DB.getConn();
 			pstmt = DB.prepareStatement(conn, sql);
 		    pstmt.setString(1,ID);
 			rs = pstmt.executeQuery();
 			while (rs.next()) {
 				apManage = new ApManage();
 				apManage.setApM_id(rs.getInt("SID"));
 				apManage.setS_StClassName(rs.getString("S_StClassName"));
 				apManage.setYears(rs.getString("years"));
 				apManage.setTypeName(rs.getString("name"));
 				apManage.setApTitle(rs.getString("ApTitle"));
 				apManage.setStu_account(rs.getString("Stu_account"));
 				apManage.setStateName(rs.getString("names"));
 				apManage.setApContent(rs.getString("ApContent"));
 				apManage.setCou_name(rs.getString("Cou_name"));
 				apManage.setApReCode1(rs.getString("ApReCode1"));
 				apManage.setLea_name(rs.getString("Lea_name"));
 				apManage.setApReCode2(rs.getString("ApReCode2"));
 				
 				list.add(apManage);
 			}
 		} catch (SQLException e) {
 			e.printStackTrace();
 		} finally {
 			DB.close(rs);
 			DB.close(pstmt);
 			DB.close(conn);
 		}

 		return list;
   	     }
	 //ȡ�����е�ѧ��
     public static List<Year> findAllyear(){
    		List<Year> list=new ArrayList<Year>();
    		String sql="select SID,yearCode,yearname from t_year";
    		Connection conn=null;
    		Statement stmt=null;
    		PreparedStatement pstm=null;
    		ResultSet rs=null;
    		conn=DB.getConn();
    		pstm=DB.prepareStatement(conn, sql);
    		Year years=null;
    		
    		try {
    			
    			rs=pstm.executeQuery();
    			while(rs.next()){
    			years=new Year();	
    			years.setSid(rs.getInt("sid"));
    			years.setYearCode(rs.getString("yearCode"));
    			years.setYears(rs.getString("yearname"));
    			list.add(years);
    			}
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}finally{
    		 DB.close(conn);
    		 DB.close(pstm);
    		}
    		return list;
    	}
     //ȡ�����е�רҵ
     public static List<StuClass> findAllclass(){
    		List<StuClass> list=new ArrayList<StuClass>();
    		String sql="select S_Stcode,S_ClassName  from t_StudyClass";
    		Connection conn=null;
    		Statement stmt=null;
    		PreparedStatement pstm=null;
    		ResultSet rs=null;
    		conn=DB.getConn();
    		pstm=DB.prepareStatement(conn, sql);
    		StuClass Classlist=null;
    		
    		try {
    			
    			rs=pstm.executeQuery();
    			while(rs.next()){
    			Classlist=new StuClass();	
    			Classlist.setStcode(rs.getString("S_Stcode"));
    			Classlist.setClassname(rs.getString("S_ClassName"));
    		
    			list.add(Classlist);
    			}
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}finally{
    		 DB.close(conn);
    		 DB.close(pstm);
    		}
    		return list;
    	}
     //ȡ����ѧ���ҵ������
     
     public static List<ScholarShipType> findAllScholarshipType(String type_ID){
 		List<ScholarShipType> list=new ArrayList<ScholarShipType>();
 		String sql="select numbers,name from t_business where type_ID=?";
 		Connection conn=null;
 		Statement stmt=null;
 		PreparedStatement pstm=null;
 		ResultSet rs=null;
 		conn=DB.getConn();
 		pstm=DB.prepareStatement(conn, sql);
 		
 		ScholarShipType scholarShipType=null;
 		
 		try {
 			pstm.setString(1,type_ID);
 			rs=pstm.executeQuery();
 			while(rs.next()){
 		    scholarShipType=new ScholarShipType();	
 		    scholarShipType.setNumbers(rs.getString("numbers"));
		    scholarShipType.setName(rs.getString("name"));
 			list.add(scholarShipType);
 			}
 		} catch (SQLException e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}finally{
 		 DB.close(conn);
 		 DB.close(pstm);
 		}
 		return list;
 	}
   //ɾ�������飨����������ID��
     public void delAplication(String SID){
           String sql = "delete from t_ApManage where  SID=?";
	         Connection conn = null;
                PreparedStatement pstmt = null;
               try {
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			pstmt.setString(1,SID);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(pstmt);
			DB.close(conn);
	       }
     }
     
   //����SID������Ӧ��������
     public ApManage findApManagebySID(String SID)
     {
   	  String sql="select a.SID,a.S_StClassName,a.years,b.name,a.ApTitle,a.Stu_account,c.names,a.ApContent,a.Cou_name,a.Lea_name,a.typeName,d.yearname,e.S_ClassName from t_ApManage a,t_business b,(select name as names,numbers from t_business ) c,t_Year d,t_StudyClass e where a.typeName=b.numbers and a.stateName=c.numbers and d.yearCode=a.years and a.S_StClassName=e.S_Stcode and a.SID=?";


   	      Connection conn = null;
 		  PreparedStatement pstmt = null;
 		  ResultSet rs = null;
 		  ApManage apManage = null;

 		try {		
 			conn = DB.getConn();
 			pstmt = DB.prepareStatement(conn, sql);
 		    pstmt.setString(1,SID);
 			rs = pstmt.executeQuery();
 			while (rs.next()) {
 				apManage = new ApManage();
 				apManage.setApM_id(rs.getInt("SID"));
 				apManage.setS_StClassName(rs.getString("S_StClassName"));
 				apManage.setYears(rs.getString("years"));
 				apManage.setTypeName(rs.getString("name"));
 				apManage.setApTitle(rs.getString("ApTitle"));
 				apManage.setStu_account(rs.getString("Stu_account"));
 				apManage.setStateName(rs.getString("names"));
 				apManage.setApContent(rs.getString("ApContent"));
 				apManage.setCou_name(rs.getString("Cou_name"));
 				apManage.setLea_name(rs.getString("Lea_name"));		
 				apManage.setTypenumber(rs.getString("typeName"));
 				apManage.setYearsname(rs.getString("yearname"));
 				apManage.setS_StClassNamenumber(rs.getString("S_ClassName"));
 			}
 		} catch (SQLException e) {
 			e.printStackTrace();
 		} finally {
 			DB.close(rs);
 			DB.close(pstmt);
 			DB.close(conn);
 		}

 		   return apManage;
   	     }

     
     //ѧ���ύ�ã�����״̬����
     public void setAplication(String SID ,String numbers){
            String sql = "update t_ApManage set stateName=? where  SID=?";
	    Connection conn = null;
                 PreparedStatement pstmt = null;
                try {
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			pstmt.setString(1,numbers);
			pstmt.setString(2,SID);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace(); 
		} finally {
			DB.close(pstmt);
			DB.close(conn);
	       }

      }
     //����һ����ApManage����
     public ApManage setApManagenull(ApManage apManage){
    	 apManage.setApContent("���������������ݣ�");
    	 apManage.setApReCode1("");
    	 apManage.setApReCode2("");
    	 apManage.setApTitle("");
    	 apManage.setCou_name("");
    	 apManage.setLea_name("");
    	 apManage.setStateName("");
    	 apManage.setS_StClassName("");
    	 apManage.setStu_account("");
    	 apManage.setTypeName("");
    	 apManage.setYears("");
    	 apManage.setYearsname("");
    	 apManage.setTypenumber("");
    	 apManage.setS_StClassNamenumber("");
    	 
    	 return apManage;
     }
     
   //����������ID�޸������� 
     public void updAplication(ApManage AP,String SID){
     String sql = "update t_ApManage set S_StClassName=?,years=?,typeName=?,ApTitle=?,Stu_account=?,stateName=?,ApContent=?,Cou_name=?,ApReCode1=?,Lea_name=?,ApReCode2=? where SID=?";
       Connection conn = null;
	   PreparedStatement pstmt = null;
	   ResultSet rs = null;
	  try {
		conn = DB.getConn();
		pstmt = DB.prepareStatement(conn, sql);
		pstmt.setString(1,AP.getS_StClassName());
      pstmt.setString(2,AP.getYears()); 
      pstmt.setString(3,AP.getTypeName());
      pstmt.setString(4,AP.getApTitle());
      pstmt.setString(5,AP.getStu_account());
      pstmt.setString(6,AP.getStateName());
      pstmt.setString(7,AP.getApContent());
      pstmt.setString(8,AP.getCou_name());
      pstmt.setString(9,AP.getApReCode1());
      pstmt.setString(10,AP.getLea_name());
      pstmt.setString(11,AP.getApReCode2());
      pstmt.setString(12, SID);
		pstmt.executeUpdate();
	         } catch (SQLException e) {
			e.printStackTrace();
	         } finally {
	    	           DB.close(rs);
		           DB.close(pstmt);
		           DB.close(conn);
                     }

      }
}
