package com.scholarshipsystem.student.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.scholarship.student.model.StuClass;
import com.scholarship.student.model.Student;
import com.scholarship.util.DB;
import com.scholarshipsystem.student.model.ApManage;
import com.scholarshipsystem.student.model.HomeSituation;

public class PersoninfoDAO {

		public Student findPersoninfoByNumber(String number) {
			String sql = "select a.*,b.S_ClassName from t_studentinfo a,t_StudyClass b where a.S_StClassName=b.S_Stcode  and Stu_account=?";
			Connection conn = null;
			PreparedStatement pstm = null;
			ResultSet rs = null;
			conn = DB.getConn();
			pstm = DB.prepareStatement(conn, sql);
			Student student = null;
			try {
				pstm.setString(1, number);
				rs = pstm.executeQuery();
				if (rs.next()) {
					student = new Student();
					student.setStudentId(rs.getInt("SID"));
					student.setStudentAccount(rs.getString("Stu_account"));
					student.setStudentPassword(rs.getString("Stu_password").trim());
					student.setStudentState(rs.getString("Stu_state"));
					student.setStudentRole(rs.getString("Stu_role"));
					student.setStudentName(rs.getString("Stu_name"));
					student.setStudentSex(rs.getString("Stu_sex"));
					student.setStudentBrithday(rs.getString("Stu_birthday"));
					student.setStudentNativePlace(rs.getString("nativePlace"));
					student.setStudentPolitical(rs.getString("political"));
					student.setStudentNation(rs.getString("nation"));
					student.setStudentIdCard(rs.getString("IdCard"));
					student.setStudentClassName(rs.getString("S_StClassName"));
					student.setStudentTel(rs.getString("Stu_tel"));
					student.setStudentHomeAddress(rs.getString("homeAddress"));
					student.setStudentClassNumber(rs.getString("S_ClassName"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				DB.close(rs);
				DB.close(pstm);
				DB.close(conn);
			}

			return student;
		}
		
		 //ȡ�����е�רҵ
	     public static List<StuClass> findAllclass(){
	    		List<StuClass> list=new ArrayList<StuClass>();
	    		String sql="select S_Stcode,S_ClassName  from t_StudyClass";
	    		Connection conn=null;
	    		Statement stmt=null;
	    		PreparedStatement pstm=null;
	    		ResultSet rs=null;
	    		conn=DB.getConn();
	    		pstm=DB.prepareStatement(conn, sql);
	    		StuClass Classlist=null;
	    		
	    		try {
	    			
	    			rs=pstm.executeQuery();
	    			while(rs.next()){
	    			Classlist=new StuClass();	
	    			Classlist.setStcode(rs.getString("S_Stcode"));
	    			Classlist.setClassname(rs.getString("S_ClassName"));
	    		
	    			list.add(Classlist);
	    			}
	    		} catch (SQLException e) {
	    			// TODO Auto-generated catch block
	    			e.printStackTrace();
	    		}finally{
	    		 DB.close(conn);
	    		 DB.close(pstm);
	    		}
	    		return list;
	    	}
		
	     //����ѧ���޸ļ�ͥ����
	     public void updatePersoninfoByaccount(Student student,String account){
	     	
	     	String sql = "update t_studentinfo set Stu_name=?,Stu_sex=?,Stu_birthday=?,nativePlace=?,political=?,nation=?,IdCard=?,S_StClassName=?,Stu_tel=?,homeAddress=? where Stu_account=?";
	           
	     	  Connection conn = null;
	  	      PreparedStatement pstmt = null;
	  	      ResultSet rs = null;
	  	  try {
	  		  conn = DB.getConn();
	  		   pstmt = DB.prepareStatement(conn, sql);
	  		   pstmt.setString(1, student.getStudentName());
	  		   pstmt.setString(2, student.getStudentSex());
	  		   pstmt.setString(3, student.getStudentBrithday());
		  	   pstmt.setString(4, student.getStudentNativePlace());
		  	   pstmt.setString(5, student.getStudentPolitical());
		  	   pstmt.setString(6, student.getStudentNation());
		   	   pstmt.setString(7, student.getStudentIdCard());
		  	   pstmt.setString(8, student.getStudentClassName());
		  	   pstmt.setString(9, student.getStudentTel());
		  	   pstmt.setString(10, student.getStudentHomeAddress());
		  	   pstmt.setString(11, account);
	  		 
	  		   
	  		   pstmt.executeUpdate();
	  	         } catch (SQLException e) {
	  			e.printStackTrace();
	  	         } finally {
	  	    	       DB.close(rs);
	  		           DB.close(pstmt);
	  		           DB.close(conn);
	                         }
	     	
	     }
	   //����һ����Student����
	     public Student setStudentnull(String account){
	    	 Student student=new Student();
	    	 student.setStudentAccount(account);
	    	 student.setStudentName("");
	    	 student.setStudentSex("1");
	    	 student.setStudentClassName("01");
	    	 student.setStudentBrithday("");
	    	 student.setStudentNativePlace("");
	    	 student.setStudentPolitical("");
	    	 student.setStudentNation("");
	    	 student.setStudentIdCard("");
	    	 student.setStudentTel("");
	    	 student.setStudentHomeAddress("");
	    	 
	    	 return student;
	     }
		
		
		
}
