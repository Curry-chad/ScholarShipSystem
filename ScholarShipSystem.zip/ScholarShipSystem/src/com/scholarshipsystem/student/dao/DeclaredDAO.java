package com.scholarshipsystem.student.dao;

import java.sql.SQLException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.scholarship.student.model.Declare;
import com.scholarship.student.model.ScholarShipType;
import com.scholarship.student.model.StuClass;
import com.scholarship.student.model.Year;
import com.scholarship.util.*;
import com.scholarshipsystem.student.model.*;

  public class DeclaredDAO {  
	  //���ӹ���������

      public void addDeclare(Declare AD)
      {
       String sql = "insert into t_Declared(Dec_title,Dec_info,Dec_state) values (?,?,?)";
      Connection conn = null;
	   PreparedStatement pstmt = null;
	   ResultSet rs = null;
	  try {
		     conn = DB.getConn();
		     pstmt =DB.prepareStatement(conn, sql);
		     pstmt.setString(1,AD.getDec_title()); 
             pstmt.setString(2,AD.getDec_info());
             pstmt.setString(3,AD.getDec_state());
	         pstmt.executeUpdate();
	         } catch (SQLException e) {
			e.printStackTrace();
	         } finally {
	    	       DB.close(rs);
		           DB.close(pstmt);
		           DB.close(conn);
                    }
     }
    
    
    
    
    //����State��ѯ������
	public List<Declare> findDeclareAllBySate(String state) {
		List<Declare> list = null;
		
		String sql = "select SID,Dec_title,Dec_time,Dec_info,Dec_state from t_Declared where Dec_state=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Declare D = null;
		
		try {
			list = new ArrayList<Declare>();
			
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			pstmt.setString(1, state);
			rs = pstmt.executeQuery();		
			while (rs.next()) {
				D = new Declare();
				D.setSID(rs.getInt("SID"));
				D.setDec_title(rs.getString("Dec_title"));
				D.setDec_time(rs.getString("Dec_time"));
				D.setDec_info(rs.getString("Dec_info"));
				D.setDec_state(rs.getString("Dec_state"));			
				list.add(D);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(pstmt);
			DB.close(conn);
		}
		
		
		return list;
	}

	 //����SID��ѯ������
   	public Declare findByID(String id) {
		Declare D = null;
		
		String sql = "select SID,Dec_title,Dec_time,Dec_info,Dec_state from t_Declared where SID=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				D = new Declare();
				D.setSID(rs.getInt("SID"));
				D.setDec_title(rs.getString("Dec_title"));
				D.setDec_time(rs.getString("Dec_time"));
				D.setDec_info(rs.getString("Dec_info"));
				D.setDec_state(rs.getString("Dec_state"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(pstmt);
			DB.close(conn);
		}
		
		return D;
	}

}
