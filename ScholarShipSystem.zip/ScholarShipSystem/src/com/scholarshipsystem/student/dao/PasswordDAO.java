package com.scholarshipsystem.student.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;

import com.scholarship.util.DB;

public class PasswordDAO {
  //����ѧ���޸�����
	public void updatePassword(String user_ID,String password){
		
		String sql = "update t_StudentInfo set Stu_password=? where Stu_account=?";
        
    	Connection conn = null;
 	      PreparedStatement pstmt = null;
 	      ResultSet rs = null;
 	  try {
 		  conn = DB.getConn();
 		   pstmt = DB.prepareStatement(conn, sql);
 		   pstmt.setString(1,password);
 		   pstmt.setString(2,user_ID);
 		   
 		   pstmt.executeUpdate();
 	         } catch (SQLException e) {
 			e.printStackTrace();
 	         } finally {
 	    	       DB.close(rs);
 		           DB.close(pstmt);
 		           DB.close(conn);
                        }
	}
	
	
}
