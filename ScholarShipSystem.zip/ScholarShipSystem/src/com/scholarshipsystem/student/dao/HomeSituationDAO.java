package com.scholarshipsystem.student.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.scholarship.util.DB;
import com.scholarshipsystem.student.model.ApManage;
import com.scholarshipsystem.student.model.HomeSituation;



public class HomeSituationDAO {

	//������ͥ���� 
    public List<HomeSituation> findHomeSituationbyID(String account)
    {
  	  List<HomeSituation> list=null;
  	  String sql="select SID,Stu_account,merberName,homeMerL,work,workPlace,yearEarning from t_HomeSituation where Stu_account=?";
		      
	      Connection conn = null;
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;
	      HomeSituation homeSituation = null;
	      try {
	  			list = new ArrayList<HomeSituation>();
	  			
	  			conn = DB.getConn();
	  			pstmt = DB.prepareStatement(conn, sql);
	  			pstmt.setString(1,account);
	  			rs = pstmt.executeQuery();

	  			while (rs.next()) {
	  				homeSituation = new HomeSituation();  				
	  				homeSituation.setSID(rs.getInt("SID"));				
	  				homeSituation.setStu_account(rs.getString("Stu_account"));
	  				homeSituation.setMerberName(rs.getString("merberName"));
	  				homeSituation.setHomeMerL(rs.getString("homeMerL"));
	  				homeSituation.setWork(rs.getString("work"));
	  				homeSituation.setWorkPlace(rs.getString("workPlace"));
	  				homeSituation.setYearEarning(rs.getString("yearEarning"));
	  				
	  				
	  				list.add(homeSituation);
	  			}
	  		} catch (SQLException e) {
	  			e.printStackTrace();
	  		} finally {
	  			DB.close(rs);
	  			DB.close(pstmt);
	  			DB.close(conn);
	  		}

	  		return list;  
      }
    //���Ӽ�ͥ����
    public void addHomeSituation(HomeSituation HS){
        String sql = "insert into t_HomeSituation (Stu_account,merberName,homeMerL,work,workPlace,yearEarning) values (?,?,?,?,?,?)";
        Connection conn = null;
 	      PreparedStatement pstmt = null;
 	      ResultSet rs = null;
 	  try {
 		  conn = DB.getConn();
 		   pstmt = DB.prepareStatement(conn, sql);
 		   pstmt.setString(1,HS.getStu_account());
         pstmt.setString(2,HS.getMerberName()); 
         pstmt.setString(3,HS.getHomeMerL());
         pstmt.setString(4,HS.getWork());
         pstmt.setString(5,HS.getWorkPlace());
         pstmt.setString(6,HS.getYearEarning());
 		   pstmt.executeUpdate();
 	         } catch (SQLException e) {
 			e.printStackTrace();
 	         } finally {
 	    	       DB.close(rs);
 		           DB.close(pstmt);
 		           DB.close(conn);
                        }
 	         }
   //����SID���Ҽ�ͥ��Ϣ
    public HomeSituation findHomeSituationbySID(String SID){
    	 String sql="select SID,Stu_account,merberName,homeMerL,work,workPlace,yearEarning from t_HomeSituation where SID=?";
	      
	      Connection conn = null;
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;
	      HomeSituation homeSituation = null;
	      try {
                		
	    	  
	  			conn = DB.getConn();
	  			pstmt = DB.prepareStatement(conn, sql);
	  			pstmt.setString(1,SID);
	  			rs = pstmt.executeQuery();

	  			while (rs.next()) {
	  				homeSituation = new HomeSituation();  				
	  				homeSituation.setSID(rs.getInt("SID"));				
	  				homeSituation.setStu_account(rs.getString("Stu_account"));
	  				homeSituation.setMerberName(rs.getString("merberName"));
	  				homeSituation.setHomeMerL(rs.getString("homeMerL"));
	  				homeSituation.setWork(rs.getString("work"));
	  				homeSituation.setWorkPlace(rs.getString("workPlace"));
	  				homeSituation.setYearEarning(rs.getString("yearEarning"));
	  				
	  			}
	  		} catch (SQLException e) {
	  			e.printStackTrace();
	  		} finally {
	  			DB.close(rs);
	  			DB.close(pstmt);
	  			DB.close(conn);
	  		}

	  		return homeSituation;  
    	
    }
  //����һ����HomeSituationDAO����
    public HomeSituation setApHomeSituationDAOnull(){
    	HomeSituation homesituation=new HomeSituation();
    	homesituation.setHomeMerL("");
    	homesituation.setMerberName("");
    	homesituation.setStu_account("");
    	homesituation.setWork("");
    	homesituation.setWorkPlace("");
    	homesituation.setYearEarning("");
    	
    	
   	 return homesituation;
    }
    
    //����SID�޸ļ�ͥ����
    public void updateHomeSituationBySID(HomeSituation homesituation,String SID){
    	
    	String sql = "update t_HomeSituation set merberName=?,homeMerL=?,work=?,workPlace=?,yearEarning=? where SID=?";
          
    	Connection conn = null;
 	      PreparedStatement pstmt = null;
 	      ResultSet rs = null;
 	  try {
 		  conn = DB.getConn();
 		   pstmt = DB.prepareStatement(conn, sql);
 		   pstmt.setString(1,homesituation.getMerberName());
 		   pstmt.setString(2,homesituation.getHomeMerL());
 		   pstmt.setString(3,homesituation.getWork());
 		   pstmt.setString(4,homesituation.getWorkPlace());
 		   pstmt.setString(5,homesituation.getYearEarning());
 		   pstmt.setString(6,SID);
 		   
 		   pstmt.executeUpdate();
 	         } catch (SQLException e) {
 			e.printStackTrace();
 	         } finally {
 	    	       DB.close(rs);
 		           DB.close(pstmt);
 		           DB.close(conn);
                        }
    	
    }
    //����SIDɾ��ѧ������
    public void delHomeSituation(String SID){
        String sql = "delete from t_HomeSituation where  SID=?";
	         Connection conn = null;
             PreparedStatement pstmt = null;
            try {
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			pstmt.setString(1,SID);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(pstmt);
			DB.close(conn);
	       }
  }
    //����SID������Ӧ�ļ�ͥ����
    public HomeSituation findHomeSituation(String SID)
    {
    	 String sql="select SID,Stu_account,merberName,homeMerL,work,workPlace,yearEarning from t_HomeSituation where SID=?";
	      
	      Connection conn = null;
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;
	      HomeSituation homeSituation = null;
	      try {
	  			
	  			
	  			conn = DB.getConn();
	  			pstmt = DB.prepareStatement(conn, sql);
	  			pstmt.setString(1,SID);
	  			rs = pstmt.executeQuery();

	  			while (rs.next()) {
	  				homeSituation = new HomeSituation();  				
	  				homeSituation.setSID(rs.getInt("SID"));				
	  				homeSituation.setStu_account(rs.getString("Stu_account"));
	  				homeSituation.setMerberName(rs.getString("merberName"));
	  				homeSituation.setHomeMerL(rs.getString("homeMerL"));
	  				homeSituation.setWork(rs.getString("work"));
	  				homeSituation.setWorkPlace(rs.getString("workPlace"));
	  				homeSituation.setYearEarning(rs.getString("yearEarning"));
	  			}
	  		} catch (SQLException e) {
	  			e.printStackTrace();
	  		} finally {
	  			DB.close(rs);
	  			DB.close(pstmt);
	  			DB.close(conn);
	  		}

	  		return homeSituation;  
  	     }
}
