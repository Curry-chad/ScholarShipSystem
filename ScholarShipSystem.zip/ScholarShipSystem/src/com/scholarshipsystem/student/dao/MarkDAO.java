//package com.scholarshipsystem.student.dao;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//
//import com.scholarship.student.model.Grade;
//import com.scholarship.util.DB;
//import com.scholarshipsystem.student.model.ApManage;
//
//public class MarkDAO {
//
//	 //����ѧ�Ų��ҷ���
//    public List<Grade> findAllGradebyaccount(String account)
//    {
//  	  List<Grade> list=null;
//  	  String sql="select s.Stu_account,s.Stu_name,g.stuff,g.credit,g.grade,b.name,y.yearname"
//              +" from t_StudentInfo s,t_Grade g,t_business b,t_Year y "
//              +" where s.Stu_account=g.Stu_account and g.grade_state=b.numbers and g.years=y.yearCode and s.Stu_account=?";
//  	      Connection conn = null;
//		  PreparedStatement pstmt = null;
//		  ResultSet rs = null;
//		  Grade grade = null;
//
//		try {
//			list = new ArrayList<Grade>();
//			
//			conn = DB.getConn();
//			pstmt = DB.prepareStatement(conn, sql);
//		    pstmt.setString(1,account);
//			rs = pstmt.executeQuery();
//			while (rs.next()) {
//				grade = new Grade();
//				apManage.setApM_id(rs.getInt("SID"));
//				
//				
//				list.add(grade);
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			DB.close(rs);
//			DB.close(pstmt);
//			DB.close(conn);
//		}
//
//		return list;
//  	     }
//    //����ѧ�Ų��ҷ���
//    public List<Grade> findAllGradebyaccount(String account)
//    {
//  	  List<Grade> list=null;
//  	  String sql="select s.Stu_account,s.Stu_name,g.stuff,g.credit,g.grade,b.name,y.yearname"
//              +" from t_StudentInfo s,t_Grade g,t_business b,t_Year y "
//              +" where s.Stu_account=g.Stu_account and g.grade_state=b.numbers and g.years=y.yearCode and s.Stu_account=?";
//  	      Connection conn = null;
//		  PreparedStatement pstmt = null;
//		  ResultSet rs = null;
//		  Grade grade = null;
//
//		try {
//			list = new ArrayList<Grade>();
//			
//			conn = DB.getConn();
//			pstmt = DB.prepareStatement(conn, sql);
//		    pstmt.setString(1,account);
//			rs = pstmt.executeQuery();
//			while (rs.next()) {
//				grade = new Grade();
//				apManage.setApM_id(rs.getInt("SID"));
//				
//				
//				list.add(grade);
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} finally {
//			DB.close(rs);
//			DB.close(pstmt);
//			DB.close(conn);
//		}
//
//		return list;
//  	     }
//	
//	
//	
//}
