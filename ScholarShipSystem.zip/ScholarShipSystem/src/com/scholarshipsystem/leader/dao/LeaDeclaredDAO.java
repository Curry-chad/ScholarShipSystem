package com.scholarshipsystem.leader.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.scholarship.student.model.Declare;
import com.scholarship.util.DB;
import com.scholarshipsystem.student.model.ApManage;

public class LeaDeclaredDAO {

   	//ȡ�����еĹ���
	public List<Declare> findDeclareAll() {
		List<Declare> list = null;
		
		String sql = "select SID,Dec_title,Dec_time,Dec_info,Dec_state,name from t_Declared,t_business where t_business.numbers=t_Declared.Dec_state";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Declare D = null;
		
		try {
			list = new ArrayList<Declare>();
			
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				D = new Declare();
				D.setSID(rs.getInt("SID"));
				D.setDec_title(rs.getString("Dec_title"));
				D.setDec_time(rs.getString("Dec_time"));
				D.setDec_info(rs.getString("Dec_info"));
				D.setDec_state(rs.getString("Dec_state"));
				D.setDec_statename(rs.getString("name"));
				list.add(D);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(pstmt);
			DB.close(conn);
		}
		
		
		return list;
	}
	
	 //����SID��ѯ������
   	public Declare findByID(String id) {
		Declare D = null;
		
		String sql = "select SID,Dec_title,Dec_time,Dec_info,Dec_state from t_Declared where SID=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				D = new Declare();
				D.setSID(rs.getInt("SID"));
				D.setDec_title(rs.getString("Dec_title"));
				D.setDec_time(rs.getString("Dec_time"));
				D.setDec_info(rs.getString("Dec_info"));
				D.setDec_state(rs.getString("Dec_state"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(pstmt);
			DB.close(conn);
		}
		
		return D;
	}
	
  //ɾ�����������ݣ�����������SID��
    public void delDeclare(String SID){
          String sql = "delete from t_Declared where  SID=?";
	      Connection conn = null;
          PreparedStatement pstmt = null;
    try {
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
         pstmt.setString(1, SID);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(pstmt);
			DB.close(conn);
	       }
    }
    
    
    
  //�޸Ĺ����״̬
	public void updDeclareBystate(String SID,String state){
		
		String sql = "update t_Declared set Dec_state=?,Dec_time='��' where SID=?";
		if(state.equals("0302")){sql = "update t_Declared set Dec_state=?,Dec_time=convert(varchar(100),getdate()) where SID=?";}
			
    	Connection conn = null;
 	      PreparedStatement pstmt = null;
 	      ResultSet rs = null;
 	  try {
 		  conn = DB.getConn();
 		   pstmt = DB.prepareStatement(conn, sql);
 		   pstmt.setString(1,state);
 		   pstmt.setString(2,SID);		   
 		   pstmt.executeUpdate();
 	         } catch (SQLException e) {
 			e.printStackTrace();
 	         } finally {
 	    	       DB.close(rs);
 		           DB.close(pstmt);
 		           DB.close(conn);
                        }
	}
    
	//�޸Ĺ���
	public void updDeclare(String SID,Declare declare){
		
		String sql = "update t_Declared set Dec_title=?,Dec_info=?  where SID=?";
			
    	Connection conn = null;
 	      PreparedStatement pstmt = null;
 	      ResultSet rs = null;
 	  try {
 		  conn = DB.getConn();
 		   pstmt = DB.prepareStatement(conn, sql);
 		   pstmt.setString(1,declare.getDec_title());
 		  pstmt.setString(2,declare.getDec_info());
 		   pstmt.setString(3,SID);		   
 		   pstmt.executeUpdate();
 	         } catch (SQLException e) {
 			e.printStackTrace();
 	         } finally {
 	    	       DB.close(rs);
 		           DB.close(pstmt);
 		           DB.close(conn);
                        }
	}
	//����һ����ApManage����
    public Declare setDeclarenull(Declare declare){
    	declare.setDec_info("");
    	declare.setDec_state("");
    	declare.setDec_statename("");
    	declare.setDec_time("");
    	declare.setDec_title("");
    	declare.setSID(0);   	 
   	 return declare;
    }
    //���ӹ���
    public void addDeclare(Declare declare){
	       String sql = "insert into t_Declared (Dec_title,Dec_info,Dec_state) values (?,?,'0301')";
	       Connection conn = null;
		   PreparedStatement pstmt = null;
		   ResultSet rs = null;
		   
		  try {
		    conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			pstmt.setString(1,declare.getDec_title());
			pstmt.setString(2,declare.getDec_info());
			pstmt.executeUpdate();
		         } catch (SQLException e) {
				e.printStackTrace();
		         } finally {
		    	       DB.close(rs);
			           DB.close(pstmt);
			           DB.close(conn);
	                       }

	        }
    
    //����State��ѯ������
	public List<Declare> findDeclareAllBySate(String state) {
		List<Declare> list = null;
		
		String sql = "select SID,Dec_title,Dec_time,Dec_info,Dec_state,name from t_Declared,t_business where t_business.numbers=t_Declared.Dec_state and  Dec_state=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Declare D = null;
		
		try {
			list = new ArrayList<Declare>();
			
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			pstmt.setString(1, state);
			rs = pstmt.executeQuery();		
			while (rs.next()) {
				D = new Declare();
				D.setSID(rs.getInt("SID"));
				D.setDec_title(rs.getString("Dec_title"));
				D.setDec_time(rs.getString("Dec_time"));
				D.setDec_info(rs.getString("Dec_info"));
				D.setDec_state(rs.getString("Dec_state"));
				D.setDec_statename(rs.getString("name"));
				list.add(D);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(pstmt);
			DB.close(conn);
		}
		
		
		return list;
	}
	
}
