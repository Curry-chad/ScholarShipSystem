package com.scholarshipsystem.leader.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.scholarship.student.model.Counsellor;
import com.scholarship.student.model.Declare;
import com.scholarship.student.model.ScholarShipType;
import com.scholarship.student.model.StuClass;
import com.scholarship.student.model.Student;
import com.scholarship.util.DB;
import com.scholarshipsystem.student.model.ApManage;
import com.scholarshipsystem.student.model.HomeSituation;

public class LeaAccountsDAO {
	
	 //���Ҹ���Ա�ʺ�
    public List<Counsellor> findAllCounsellor()
    {
  	  List<Counsellor> list=null;
  	  String sql="select Cou_account,Cou_state,name,S_ClassName from t_CounsellorInfo,t_business,t_StudyClass where t_CounsellorInfo.Cou_state=t_business.numbers and t_StudyClass.S_Stcode=t_CounsellorInfo.Cou_class";

  	      Connection conn = null;
		  PreparedStatement pstmt = null;
		  ResultSet rs = null;
		  Counsellor counsellor = null;

		try {
			list = new ArrayList<Counsellor>();
			
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				counsellor = new Counsellor();			
				counsellor.setCou_account(rs.getString("Cou_account"));
				counsellor.setCou_state(rs.getString("Cou_state"));
				counsellor.setCou_statename(rs.getString("name"));
				counsellor.setCou_classname(rs.getString("S_ClassName"));
				
				list.add(counsellor);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(pstmt);
			DB.close(conn);
		}

		return list;
  	     }
	
    
  //����ѧ���ʺ�
    public List<Student> findAllStudent()
    {
  	  List<Student> list=null;
  	  String sql="select Stu_account,Stu_state,name from t_StudentInfo,t_business where t_StudentInfo.Stu_state=t_business.numbers";

  	      Connection conn = null;
		  PreparedStatement pstmt = null;
		  ResultSet rs = null;
		  Student student = null;

		try {
			list = new ArrayList<Student>();
			
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				student = new Student();			
				student.setStudentAccount(rs.getString("Stu_account"));
				student.setStudentState(rs.getString("Stu_state"));
				student.setStudentStatename(rs.getString("name"));
				
				list.add(student);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(pstmt);
			DB.close(conn);
		}

		return list;
  	     }
    
	//�޸ĸ���Ա�˺���Ϣ
    public void updCouAccountstateByaccount(String state,String Couclass,String account){
    String sql = "update t_CounsellorInfo set Cou_state=?,Cou_class=? where Cou_account=?";
       Connection conn = null;
	   PreparedStatement pstmt = null;
	   ResultSet rs = null;
	  try {
		conn = DB.getConn();
		pstmt = DB.prepareStatement(conn, sql);
		pstmt.setString(1,state);
		pstmt.setString(2,Couclass);
		pstmt.setString(3,account);
		pstmt.executeUpdate();
	         } catch (SQLException e) {
			e.printStackTrace();
	         } finally {
	    	           DB.close(rs);
		           DB.close(pstmt);
		           DB.close(conn);
                    }
     }
    
  //�޸�ѧ���˺���Ϣ
    public void updStuAccountstateByaccount(String state,String account){
    String sql = "update t_StudentInfo set Stu_state=? where Stu_account=?";
       Connection conn = null;
	   PreparedStatement pstmt = null;
	   ResultSet rs = null;
	  try {
		conn = DB.getConn();
		pstmt = DB.prepareStatement(conn, sql);
		pstmt.setString(1,state);
		pstmt.setString(2,account);
		pstmt.executeUpdate();
	         } catch (SQLException e) {
			e.printStackTrace();
	         } finally {
	    	           DB.close(rs);
		           DB.close(pstmt);
		           DB.close(conn);
                    }
     }
    
    
    
    
    //����account���Ҹ���Ա�ʺ�
    public Counsellor findCounsellorByaccount( String account)
    {
  	  String sql="select Cou_account,Cou_state,name,S_ClassName from t_CounsellorInfo,t_business,t_StudyClass where t_CounsellorInfo.Cou_state=t_business.numbers and t_StudyClass.S_Stcode=t_CounsellorInfo.Cou_class and Cou_account=?";

  	      Connection conn = null;
		  PreparedStatement pstmt = null;
		  ResultSet rs = null;
		  Counsellor counsellor = null;

		try {	
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			pstmt.setString(1,account);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				counsellor = new Counsellor();			
				counsellor.setCou_account(rs.getString("Cou_account"));
				counsellor.setCou_state(rs.getString("Cou_state"));
				counsellor.setCou_statename(rs.getString("name"));
				counsellor.setCou_classname(rs.getString("S_ClassName"));
	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(pstmt);
			DB.close(conn);
		}

		return counsellor;
  	     }
    
    //����account����ѧ���ʺ�
    public Student findStudentByaccount( String account)
    {
  	  String sql="select Stu_account,Stu_state,name from t_StudentInfo,t_business where t_StudentInfo.Stu_state=t_business.numbers and Stu_account=?";

  	      Connection conn = null;
		  PreparedStatement pstmt = null;
		  ResultSet rs = null;
		  Student student = null;

		try {	
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			pstmt.setString(1,account);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				student = new Student();			
				student.setStudentAccount(rs.getString("Stu_account"));
				student.setStudentState(rs.getString("Stu_state"));
				student.setStudentStatename(rs.getString("name"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(rs);
			DB.close(pstmt);
			DB.close(conn);
		}

		return student;
  	     }
    

    
    //ȡ�����е�רҵ
    public static List<StuClass> findAllclass(){
   		List<StuClass> list=new ArrayList<StuClass>();
   		String sql="select S_Stcode,S_ClassName  from t_StudyClass";
   		Connection conn=null;
   		Statement stmt=null;
   		PreparedStatement pstm=null;
   		ResultSet rs=null;
   		conn=DB.getConn();
   		pstm=DB.prepareStatement(conn, sql);
   		StuClass Classlist=null;
   		
   		try {
   			
   			rs=pstm.executeQuery();
   			while(rs.next()){
   			Classlist=new StuClass();	
   			Classlist.setStcode(rs.getString("S_Stcode"));
   			Classlist.setClassname(rs.getString("S_ClassName"));
   		
   			list.add(Classlist);
   			}
   		} catch (SQLException e) {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}finally{
   		 DB.close(conn);
   		 DB.close(pstm);
   		}
   		return list;
   	}
    //ȡ��ҵ�����״̬
    
    public static List<ScholarShipType> findAllstate(String type_ID){
		List<ScholarShipType> list=new ArrayList<ScholarShipType>();
		String sql="select numbers,name from t_business where type_ID=?";
		Connection conn=null;
		Statement stmt=null;
		PreparedStatement pstm=null;
		ResultSet rs=null;
		conn=DB.getConn();
		pstm=DB.prepareStatement(conn, sql);
		
		ScholarShipType scholarShipType=null;
		
		try {
			pstm.setString(1,type_ID);
			rs=pstm.executeQuery();
			while(rs.next()){
		    scholarShipType=new ScholarShipType();	
		    scholarShipType.setNumbers(rs.getString("numbers"));
		    scholarShipType.setName(rs.getString("name"));
			list.add(scholarShipType);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
		 DB.close(conn);
		 DB.close(pstm);
		}
		return list;
	}
    
  //ɾ������Ա�ʺ�
    public void delCouaccount(String account){
          String sql = "delete from t_CounsellorInfo where  Cou_account=?";
	      Connection conn = null;
          PreparedStatement pstmt = null;
    try {
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
         pstmt.setString(1, account);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(pstmt);
			DB.close(conn);
	       }
    }
    
    
  //ɾ��ѧ���ʺ�
    public void delStuaccount(String account){
          String sql = "delete from t_StudentInfo where  Stu_account=?";
	      Connection conn = null;
          PreparedStatement pstmt = null;
    try {
			conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
         pstmt.setString(1, account);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(pstmt);
			DB.close(conn);
	       }
    }
    
    //���Ӹ���Ա�ʺ�
    public void addCouaccount(String state,String Couclass,String account){
	       String sql = "insert into t_CounsellorInfo (Cou_account,Cou_password,Cou_state,Cou_class) values (?,?,?,?)";
	       Connection conn = null;
		   PreparedStatement pstmt = null;
		   ResultSet rs = null;
		   
		  try {
		    conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			pstmt.setString(1,account);
			pstmt.setString(2,account);
			pstmt.setString(3,state);
			pstmt.setString(4,Couclass);
			pstmt.executeUpdate();
		         } catch (SQLException e) {
				e.printStackTrace();
		         } finally {
		    	       DB.close(rs);
			           DB.close(pstmt);
			           DB.close(conn);
	                       }

	        }
    
  //����ѧ���ʺ�
    public void addStudent(String state,String account){
	       String sql = "insert into t_StudentInfo (Stu_account,Stu_password,Stu_state) values (?,?,?)";
	       Connection conn = null;
		   PreparedStatement pstmt = null;
		   ResultSet rs = null;
		   
		  try {
		    conn = DB.getConn();
			pstmt = DB.prepareStatement(conn, sql);
			pstmt.setString(1,account);
			pstmt.setString(2,account);
			pstmt.setString(3,state);
			pstmt.executeUpdate();
		         } catch (SQLException e) {
				e.printStackTrace();
		         } finally {
		    	       DB.close(rs);
			           DB.close(pstmt);
			           DB.close(conn);
	                       }

	        }
    
    
    
    
    
    
}
