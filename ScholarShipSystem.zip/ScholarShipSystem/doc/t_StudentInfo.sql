create table t_StudentInfo
(
SID  int not null auto_increment,
Stu_account   varchar(10),
Stu_password  varchar(8),
Stu_state     int,
Stu_role      varchar(6),
Stu_name      varchar(6),
Stu_sex       int,
Stu_birthday  datetime,
nativePlace   varchar(6),
political     varchar(6),
nation        varchar(6),
IdCard        varchar(18),
S_StClassName  varchar(20),
Stu_tel        varchar(11),
homeAddress   varchar(100),
primary key(SID)
)