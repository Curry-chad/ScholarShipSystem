create table t_HomeSituation
(
SID int not null auto_increment,
Stu_account varchar(10),
merberName  varchar(6),
homeMerL    varchar(8),
work        varchar(12),
workPlace   varchar(256),
yearEarning int,
primary key(SID)
)