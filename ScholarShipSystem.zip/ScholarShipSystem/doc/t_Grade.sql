create table t_Grade
(
SID      int not null auto_increment,
S_StClassName varchar(20),
term          varchar(4),
Stu_account   varchar(10),
courserName   varchar(20),
years          varchar(4),
grade          int,
primary key(SID)
)