-- MySQL dump 10.11
--
-- Host: localhost    Database: scholarship
-- ------------------------------------------------------
-- Server version	5.0.67-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_apmanage`
--

DROP TABLE IF EXISTS `t_apmanage`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_apmanage` (
  `SID` int(11) NOT NULL auto_increment,
  `S_StClassName` varchar(20) default NULL,
  `years` varchar(4) default NULL,
  `typeName` varchar(20) default NULL,
  `Stu_account` varchar(10) default NULL,
  `stateName` varchar(40) default NULL,
  `ApContent` varchar(256) default NULL,
  `Cou_name1` varchar(6) default NULL,
  `ApReCode1` varchar(256) default NULL,
  `Lea_name1` varchar(6) default NULL,
  `ApReCode2` varchar(256) default NULL,
  PRIMARY KEY  (`SID`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_apmanage`
--

LOCK TABLES `t_apmanage` WRITE;
/*!40000 ALTER TABLE `t_apmanage` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_apmanage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_counsellorinfo`
--

DROP TABLE IF EXISTS `t_counsellorinfo`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_counsellorinfo` (
  `SID` int(11) NOT NULL auto_increment,
  `Cou_account` varchar(10) default NULL,
  `Cou_password` varchar(8) default NULL,
  `Cou_state` int(11) default NULL,
  `Cou_role` varchar(6) default NULL,
  `Cou_name` varchar(6) default NULL,
  PRIMARY KEY  (`SID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=gb2312;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_counsellorinfo`
--

LOCK TABLES `t_counsellorinfo` WRITE;
/*!40000 ALTER TABLE `t_counsellorinfo` DISABLE KEYS */;
INSERT INTO `t_counsellorinfo` VALUES (1,'0000000003','66666666',1,'辅导员','王梦');
/*!40000 ALTER TABLE `t_counsellorinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_grade`
--

DROP TABLE IF EXISTS `t_grade`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_grade` (
  `SID` int(11) NOT NULL auto_increment,
  `S_StClassName` varchar(20) default NULL,
  `term` varchar(4) default NULL,
  `Stu_account` varchar(10) default NULL,
  `courserName` varchar(20) default NULL,
  `years` varchar(4) default NULL,
  `grade` int(11) default NULL,
  PRIMARY KEY  (`SID`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_grade`
--

LOCK TABLES `t_grade` WRITE;
/*!40000 ALTER TABLE `t_grade` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_grade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_homesituation`
--

DROP TABLE IF EXISTS `t_homesituation`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_homesituation` (
  `SID` int(11) NOT NULL auto_increment,
  `Stu_account` varchar(10) default NULL,
  `merberName` varchar(6) default NULL,
  `homeMerL` varchar(8) default NULL,
  `work` varchar(12) default NULL,
  `workPlace` varchar(256) default NULL,
  `yearEarning` int(11) default NULL,
  PRIMARY KEY  (`SID`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_homesituation`
--

LOCK TABLES `t_homesituation` WRITE;
/*!40000 ALTER TABLE `t_homesituation` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_homesituation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_leaderinfo`
--

DROP TABLE IF EXISTS `t_leaderinfo`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_leaderinfo` (
  `SID` int(11) NOT NULL auto_increment,
  `Lea_account` varchar(10) default NULL,
  `Lea_password` varchar(8) default NULL,
  `Lea_state` int(11) default NULL,
  `Lea_role` varchar(6) default NULL,
  `Lea_name` varchar(6) default NULL,
  PRIMARY KEY  (`SID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=gb2312;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_leaderinfo`
--

LOCK TABLES `t_leaderinfo` WRITE;
/*!40000 ALTER TABLE `t_leaderinfo` DISABLE KEYS */;
INSERT INTO `t_leaderinfo` VALUES (1,'0000000001','66666666',1,'领导','王梦');
/*!40000 ALTER TABLE `t_leaderinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_scholarshiptype`
--

DROP TABLE IF EXISTS `t_scholarshiptype`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_scholarshiptype` (
  `SID` int(11) NOT NULL auto_increment,
  `SchCode` varchar(2) default NULL,
  `typeName` varchar(20) default NULL,
  PRIMARY KEY  (`SID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=gb2312;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_scholarshiptype`
--

LOCK TABLES `t_scholarshiptype` WRITE;
/*!40000 ALTER TABLE `t_scholarshiptype` DISABLE KEYS */;
INSERT INTO `t_scholarshiptype` VALUES (1,'04','院二等奖学金');
/*!40000 ALTER TABLE `t_scholarshiptype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_state`
--

DROP TABLE IF EXISTS `t_state`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_state` (
  `SID` int(11) NOT NULL auto_increment,
  `stateCode` varchar(2) default NULL,
  `stateName` varchar(4) default NULL,
  PRIMARY KEY  (`SID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=gb2312;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_state`
--

LOCK TABLES `t_state` WRITE;
/*!40000 ALTER TABLE `t_state` DISABLE KEYS */;
INSERT INTO `t_state` VALUES (1,'02','未通过');
/*!40000 ALTER TABLE `t_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_studentinfo`
--

DROP TABLE IF EXISTS `t_studentinfo`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_studentinfo` (
  `SID` int(11) NOT NULL auto_increment,
  `Stu_account` varchar(10) default NULL,
  `Stu_password` varchar(8) default NULL,
  `Stu_state` int(11) default NULL,
  `Stu_role` varchar(6) default NULL,
  `Stu_name` varchar(6) default NULL,
  `Stu_sex` int(11) default NULL,
  `Stu_birthday` datetime default NULL,
  `nativePlace` varchar(6) default NULL,
  `political` varchar(6) default NULL,
  `nation` varchar(6) default NULL,
  `IdCard` varchar(18) default NULL,
  `S_StClassName` varchar(20) default NULL,
  `Stu_tel` varchar(11) default NULL,
  `homeAddress` varchar(100) default NULL,
  PRIMARY KEY  (`SID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=gb2312;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_studentinfo`
--

LOCK TABLES `t_studentinfo` WRITE;
/*!40000 ALTER TABLE `t_studentinfo` DISABLE KEYS */;
INSERT INTO `t_studentinfo` VALUES (1,'0000000001','66666666',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'0000000002','66666666',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `t_studentinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_study`
--

DROP TABLE IF EXISTS `t_study`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_study` (
  `SID` int(11) NOT NULL auto_increment,
  `S_Stcode` varchar(2) default NULL,
  `S_name` varchar(20) default NULL,
  `S_state` int(11) default NULL,
  PRIMARY KEY  (`SID`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_study`
--

LOCK TABLES `t_study` WRITE;
/*!40000 ALTER TABLE `t_study` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_study` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_term`
--

DROP TABLE IF EXISTS `t_term`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_term` (
  `SID` int(11) NOT NULL auto_increment,
  `yearCode` char(1) default NULL,
  `termCode` char(1) default NULL,
  `term` varchar(4) default NULL,
  PRIMARY KEY  (`SID`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_term`
--

LOCK TABLES `t_term` WRITE;
/*!40000 ALTER TABLE `t_term` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_term` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_year`
--

DROP TABLE IF EXISTS `t_year`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `t_year` (
  `SID` int(11) NOT NULL auto_increment,
  `yearCode` char(1) default NULL,
  `years` varchar(4) default NULL,
  PRIMARY KEY  (`SID`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `t_year`
--

LOCK TABLES `t_year` WRITE;
/*!40000 ALTER TABLE `t_year` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_year` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-05-02  4:25:19
