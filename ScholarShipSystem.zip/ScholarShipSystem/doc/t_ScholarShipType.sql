create table t_ScholarShipType
(
SID      int not null auto_increment,
SchCode  varchar(2),
typeName varchar(20),
primary key(SID)
)
insert into t_ScholarShipType(SchCode,typeName) values ('04','Ժ���Ƚ�ѧ��')