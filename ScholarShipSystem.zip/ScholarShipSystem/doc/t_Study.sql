create table t_Study
(
SID      int not null auto_increment,
S_Stcode varchar(2),
S_name   varchar(20),
S_state  int,
primary key(SID)

)