create table t_Year
(
SID    int not null auto_increment,
yearCode char(1),
years    varchar(4),
primary key(SID)
)