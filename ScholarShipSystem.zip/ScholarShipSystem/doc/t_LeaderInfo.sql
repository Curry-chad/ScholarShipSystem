create table t_LeaderInfo
(
SID   int  not null auto_increment,
Lea_account varchar(10),
Lea_password  varchar(8),
Lea_state     int,
Lea_role      varchar(6),
Lea_name      varchar(6),
primary key(SID )
)
insert into t_LeaderInfo(Lea_account,Lea_password ,Lea_state,Lea_role,Lea_name) values ('0000000001','66666666',1,'�쵼','����')