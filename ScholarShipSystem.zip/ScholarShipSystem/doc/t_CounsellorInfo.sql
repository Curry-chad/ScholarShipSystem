create table t_CounsellorInfo
(
SID   int  not null auto_increment,
Cou_account varchar(10),
Cou_password  varchar(8),
Cou_state     int,
Cou_role      varchar(6),
Cou_name      varchar(6),
primary key(SID )
)
insert into t_CounsellorInfo(Cou_account,Cou_password ,Cou_state,Cou_role,Cou_name) values ('0000000003','66666666',1,'����Ա','����')