create table t_Term
(
SID    int not null auto_increment,
yearCode char(1),
termCode char(1),
term     varchar(4),
primary key(SID)
)