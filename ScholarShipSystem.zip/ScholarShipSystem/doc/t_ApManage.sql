create table t_ApManage
(
SID    int not null auto_increment,
S_StClassName  varchar(20),
years           varchar(4),
typeName       varchar(20),
Stu_account    varchar(10),
stateName      varchar(40),
ApContent      varchar(256),
Cou_name1      varchar(6),
ApReCode1      varchar(256),
Lea_name1      varchar(6),
ApReCode2       varchar(256),
primary key(SID )
)