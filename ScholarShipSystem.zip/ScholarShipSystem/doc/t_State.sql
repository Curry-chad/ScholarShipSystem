create table t_State
(
SID      int not null auto_increment,
stateCode varchar(2),
stateName varchar(4),
primary key(SID)
)
insert into t_State(stateCode,stateName) values ('02','δͨ��')